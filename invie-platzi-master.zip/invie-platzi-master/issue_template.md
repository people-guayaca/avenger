## ¿Cómo puedo replicar el problema?
por favor explicanos cómo replicar el problema paso a paso y en qué sistema operativo ocurre
## ¿En qué versión de Invie-platzi ocurre?
Si este problema ocurre en todas las versiones por favor también mencionarlo
